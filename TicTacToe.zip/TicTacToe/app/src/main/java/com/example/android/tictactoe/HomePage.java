package com.example.android.tictactoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
    }

    public void OpenMainActivity2PL (View View ) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }

    public void Openplaywithcomp(View View) {
        Intent i = new Intent(this, playwithcomp.class);
        startActivity(i);
    }
//ImageView imageView = (ImageView) findViewById(R.id.imageView);
//    int alphaAmount = 128;
//
//    public int getAlphaAmount() {
//        return alphaAmount;
//    }

}

